#include <stdio.h>
int main(){

 printf("Hello, World! 666");

 return 0;

}